local QBCore = exports['qb-core']:GetCoreObject()

local liveryLocation = vector3(449.84, -976.11, 25.7)
local targetLocation = vector3(450.09, -972.97, 25.7)
local maxDistance = 3.0 -- tolerancia en metros para permitir el uso

RegisterCommand("livery", function()
    local ped = PlayerPedId()
    local pedCoords = GetEntityCoords(ped)
    local distance = #(pedCoords - liveryLocation)

    if distance > maxDistance then
        QBCore.Functions.Notify("Solo puedes usar esto en el taller autorizado.", "error")
        return
    end

    local veh = GetVehiclePedIsIn(ped, false)

    if veh == 0 then
        QBCore.Functions.Notify("Debes estar dentro del vehículo", "error")
        return
    end

    OpenLiveryMenu(veh)
end)

function OpenLiveryMenu(veh)
    local menuOptions = {}

    for i = 0, 12 do
        if DoesExtraExist(veh, i) then
            local isOn = IsVehicleExtraTurnedOn(veh, i)
            table.insert(menuOptions, {
                title = "Extra " .. i,
                description = isOn and "Desactivar" or "Activar",
                icon = isOn and "ban" or "plus",
                onSelect = function()
                    TriggerEvent("veh_extras:toggleExtra", {
                        vehicle = VehToNet(veh),
                        extra = i
                    })
                end
            })
        end
    end

    table.insert(menuOptions, {
        title = "❌ Cerrar menú",
        icon = "xmark",
        onSelect = function()
            TriggerEvent("veh_extras:closeMenu")
        end
    })

    lib.registerContext({
        id = 'livery_menu',
        title = 'Configuración de Extras',
        options = menuOptions
    })

    lib.showContext('livery_menu')
end

RegisterNetEvent("veh_extras:toggleExtra", function(data)
    local vehicle = NetToVeh(data.vehicle)
    local extra = data.extra

    if DoesExtraExist(vehicle, extra) then
        local isOn = IsVehicleExtraTurnedOn(vehicle, extra)
        SetVehicleModKit(vehicle, 0)
        SetVehicleExtra(vehicle, extra, isOn and 1 or 0)

        QBCore.Functions.Notify("Extra " .. extra .. (isOn and " desactivado." or " activado."), "success")

        OpenLiveryMenu(vehicle)
    else
        QBCore.Functions.Notify("El extra no existe", "error")
    end
end)

RegisterNetEvent("veh_extras:closeMenu", function()
    -- El menú se cierra automáticamente con ox_lib
end)

-- Spawn del objeto y qb-target
CreateThread(function()
    local model = `prop_parkingpay`
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(100)
    end

    local obj = CreateObject(model, targetLocation.x, targetLocation.y, targetLocation.z - 1.0, false, false, false)
    SetEntityHeading(obj, 0.0) -- Ajustá esto si querés otra orientación
    FreezeEntityPosition(obj, true)
    SetEntityInvincible(obj, true)
    SetEntityAsMissionEntity(obj, true, true)

    exports['qb-target']:AddTargetEntity(obj, {
        options = {
            {
                icon = "fas fa-tools",
                label = "Abrir menú de extras",
                action = function()
                    local ped = PlayerPedId()
                    local veh = GetVehiclePedIsIn(ped, false)
                    if veh == 0 then
                        QBCore.Functions.Notify("Debes estar dentro del vehículo", "error")
                        return
                    end
                    OpenLiveryMenu(veh)
                end
            }
        },
        distance = 3.0
    })
end)
