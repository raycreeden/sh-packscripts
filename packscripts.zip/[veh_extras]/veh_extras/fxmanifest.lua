fx_version 'cerulean'
game 'gta5'

description 'Gestor de Extras para Vehículos con ox_lib'
author 'SherlockCo'

lua54 'yes'  -- Necesario para ox_lib

shared_script '@ox_lib/init.lua'  -- Asegura que se cargue ox_lib

client_script 'client.lua'

dependencies {
    'qb-core',
    'ox_lib'
}
