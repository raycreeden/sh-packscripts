local QBCore = exports['qb-core']:GetCoreObject()
local targetLocation = vector3(436.7, -973.48, 25.7)

local function isPlayerInVehicle()
    local ped = PlayerPedId()
    return IsPedInAnyVehicle(ped, false)
end

local function applyMechanicalUpgrades(vehicle)
    SetVehicleModKit(vehicle, 0)

    -- Aplicar mejoras genéricas (motor, frenos, transmisión)
    SetVehicleMod(vehicle, 11, GetNumVehicleMods(vehicle, 11) - 1, false) -- Motor
    SetVehicleMod(vehicle, 12, GetNumVehicleMods(vehicle, 12) - 1, false) -- Frenos
    SetVehicleMod(vehicle, 13, GetNumVehicleMods(vehicle, 13) - 1, false) -- Transmisión
    ToggleVehicleMod(vehicle, 18, true) -- Turbo activado
end

-- Evento que aplica mejoras tanto a autos como motos
RegisterNetEvent("sh-turbo:activate", function()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)

    if veh and veh ~= 0 then
        local class = GetVehicleClass(veh)
        if class == 8 or class == 13 then -- 8 = motos, 13 = bicicletas (opcional)
            applyMechanicalUpgrades(veh)
            QBCore.Functions.Notify("Mejoras aplicadas a tu moto", "success")
        else
            applyMechanicalUpgrades(veh)
            QBCore.Functions.Notify("Mejoras aplicadas a tu vehículo", "success")
        end
    else
        QBCore.Functions.Notify("Debes estar dentro de un vehículo o moto", "error")
    end
end)

-- Spawn del banco de mejoras
CreateThread(function()
    local model = `gr_prop_gr_bench_03b`
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(100) end

    local obj = CreateObject(model,
        targetLocation.x, targetLocation.y, targetLocation.z - 1.0,
        true, true, true
    )
    SetEntityHeading(obj, 0.0)
    FreezeEntityPosition(obj, true)
    SetEntityInvincible(obj, true)
    SetEntityAsMissionEntity(obj, true, true)

    exports['qb-target']:AddTargetEntity(obj, {
        options = {
            {
                icon        = "fas fa-cog",
                label       = "Aplicar Mejoras Mecánicas",
                canInteract = function() return isPlayerInVehicle() end,
                action      = function() TriggerEvent("sh-turbo:activate") end
            }
        },
        distance = 2.5
    })
end)
