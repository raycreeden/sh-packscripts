fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Mejora Mecanica de Vehículo - QBCore'
author 'SherlockCo'

shared_script '@qb-core/shared/locale.lua'

client_script 'client.lua'

dependencies {
    'qb-target',
    'qb-core'
}
