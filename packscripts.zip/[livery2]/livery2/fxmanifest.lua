fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'TuNombre'
description 'Script Livery2 con ox_lib y NUI'
version '1.0.2'

client_script 'client.lua'
shared_script '@ox_lib/init.lua'

dependencies {
    'qb-core',
    'qb-target',
    'ox_lib'
}
