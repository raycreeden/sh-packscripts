local QBCore = exports['qb-core']:GetCoreObject()
local zonaPermitida   = vector3(449.84, -976.11, 25.7)
local distanciaMax    = 3.0
local targetUbicacion = vector3(451.58, -972.94, 25.7)

local currentVeh = nil

-- COMANDO PARA ABRIR MENÚ
RegisterCommand("livery2", function()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    if #(pos - zonaPermitida) > distanciaMax then
        QBCore.Functions.Notify("No estás en la zona autorizada", "error")
        return
    end
    local veh = QBCore.Functions.GetClosestVehicle(pos)
    if not veh or veh == 0 then
        QBCore.Functions.Notify("No hay vehículo cerca", "error")
        return
    end
    currentVeh = VehToNet(veh)
    OpenMainLiveryMenu()
end)

-- MENÚ PRINCIPAL
function OpenMainLiveryMenu()
    lib.registerContext({
        id = 'main_livery_menu',
        title = 'Modificaciones del Vehículo',
        options = {
            { title = '⚪ Prioritarios', description = 'Livery, Spoilers, Aerials, Arch Cover, Bumpers', event = 'livery2:openPriority', keepOpen = true },
            { title = '⚪ Secundarios', description = 'Faldones, Escape, Parrilla, Capó, Rear Bumper', event = 'livery2:openSecondary', keepOpen = true },
            { title = '⚪ CallSigns', description = 'Roof, Left Fender, Right Fender', event = 'livery2:openCallSigns', keepOpen = true },
            { title = '✖️ Cerrar menú', event = 'livery2:closeMenu' }
        }
    })
    lib.showContext('main_livery_menu')
end

-- SUBMENÚ PRIORITARIOS
RegisterNetEvent('livery2:openPriority', function()
    lib.registerContext({
        id = 'priority_menu',
        title = 'Prioritarios',
        options = {
            { title = ' Ⅰ - Liveries', event = 'livery2:openCategory', args = { modType = 48, title = 'Livery' }, keepOpen = true },
            { title = ' ⅠⅠ - Spoilers', event = 'livery2:openCategory', args = { modType = 0, title = 'Spoiler' }, keepOpen = true },
            { title = ' Ⅲ - Aerials', event = 'livery2:openCategory', args = { modType = 43, title = 'Aerials' }, keepOpen = true },
            { title = ' Ⅳ - Arch Cover', event = 'livery2:openCategory', args = { modType = 42, title = 'Arch Cover' }, keepOpen = true },
            { title = ' Ⅴ - Paragolpes Front', event = 'livery2:openCategory', args = { modType = 1, title = 'Paragolpes Frontal' }, keepOpen = true },
            { title = ' Ⅵ - Paragolpes Trasero', event = 'livery2:openCategory', args = { modType = 2, title = 'Paragolpes Trasero' }, keepOpen = true },
            { title = '🔙 Volver', event = 'livery2:returnToMain', keepOpen = true }
        }
    })
    lib.showContext('priority_menu')
end)

-- SUBMENÚ SECUNDARIOS
RegisterNetEvent('livery2:openSecondary', function()
    lib.registerContext({
        id = 'secondary_menu',
        title = 'Secundarios',
        options = {
            { title = ' Ⅰ - Faldones', event = 'livery2:openCategory', args = { modType = 3, title = 'Faldones' }, keepOpen = true },
            { title = ' ⅠⅠ - Escape', event = 'livery2:openCategory', args = { modType = 4, title = 'Escape' }, keepOpen = true },
            { title = ' Ⅲ - Parrilla', event = 'livery2:openCategory', args = { modType = 6, title = 'Parrilla' }, keepOpen = true },
            { title = ' Ⅳ - Capó', event = 'livery2:openCategory', args = { modType = 7, title = 'Capó' }, keepOpen = true },
            { title = ' Ⅴ - Rear Bumper', event = 'livery2:openCategory', args = { modType = 2, title = 'Paragolpes Trasero' }, keepOpen = true },
            { title = '🔙 Volver', event = 'livery2:returnToMain', keepOpen = true }
        }
    })
    lib.showContext('secondary_menu')
end)

-- SUBMENÚ CALLSIGNS
RegisterNetEvent('livery2:openCallSigns', function()
    lib.registerContext({
        id = 'callsigns_menu',
        title = 'CallSigns',
        options = {
            { title = ' Ⅰ - Roof', event = 'livery2:openCategory', args = { modType = 10, title = 'Roof' }, keepOpen = true },
            { title = ' ⅠⅠ - Left Fender', event = 'livery2:openCategory', args = { modType = 8, title = 'Left Fender' }, keepOpen = true },
            { title = ' Ⅲ - Right Fender', event = 'livery2:openCategory', args = { modType = 9, title = 'Right Fender' }, keepOpen = true },
            { title = '🔙 Volver', event = 'livery2:returnToMain', keepOpen = true }
        }
    })
    lib.showContext('callsigns_menu')
end)

-- SUBMENÚ DE CATEGORÍA
RegisterNetEvent('livery2:openCategory', function(data)
    local veh = NetToVeh(currentVeh)
    if not DoesEntityExist(veh) then
        QBCore.Functions.Notify("Vehículo no válido", "error")
        return
    end
    SetVehicleModKit(veh, 0)

    local items = {
        {
            title = '❌ Quitar mod actual',
            description = 'Restaurar a stock',
            event = 'livery2:removeMod',
            args = { modType = data.modType, title = data.title },
            keepOpen = true
        },
        {
            title = '🔙 Volver',
            event = 'livery2:returnToLast',
            args = { from = data.title },
            keepOpen = true
        }
    }

    local count = GetNumVehicleMods(veh, data.modType)
    if count > 0 then
        for i = 0, count - 1 do
            local text = GetModTextLabel(veh, data.modType, i)
            local name = text and GetLabelText(text) or ('Mod ' .. i)
            table.insert(items, {
                title = name,
                event = 'livery2:applyMod',
                args = { modType = data.modType, modIndex = i, title = data.title },
                keepOpen = true
            })
        end
    else
        table.insert(items, {
            title = '❌ No mods disponibles',
            disabled = true,
            keepOpen = true
        })
    end

    lib.registerContext({
        id = 'cat_' .. data.title,
        title = data.title,
        options = items
    })
    lib.showContext('cat_' .. data.title)
end)

-- APLICAR MOD
RegisterNetEvent('livery2:applyMod', function(data)
    local veh = NetToVeh(currentVeh)
    SetVehicleMod(veh, data.modType, data.modIndex, false)
    QBCore.Functions.Notify(data.title .. ' aplicado', 'success')
    TriggerEvent('livery2:openCategory', data)
end)

-- QUITAR MOD
RegisterNetEvent('livery2:removeMod', function(data)
    local veh = NetToVeh(currentVeh)
    if not DoesEntityExist(veh) then return end
    SetVehicleMod(veh, data.modType, -1, false)
    QBCore.Functions.Notify(data.title .. ' removido', 'success')
    TriggerEvent('livery2:openCategory', data)
end)

-- NAVIGATION
RegisterNetEvent('livery2:returnToLast', function(data)
    if data.from == 'Livery' or data.from == 'Spoiler' or data.from == 'Aerials' or data.from == 'Arch Cover' or data.from == 'Paragolpes Frontal' or data.from == 'Paragolpes Trasero' then
        TriggerEvent('livery2:openPriority')
    elseif data.from == 'Faldones' or data.from == 'Escape' or data.from == 'Parrilla' or data.from == 'Capó' then
        TriggerEvent('livery2:openSecondary')
    elseif data.from == 'Roof' or data.from == 'Left Fender' or data.from == 'Right Fender' then
        TriggerEvent('livery2:openCallSigns')
    else
        OpenMainLiveryMenu()
    end
end)
RegisterNetEvent('livery2:returnToMain', OpenMainLiveryMenu)

-- CERRAR MENÚ
RegisterNetEvent('livery2:closeMenu', function()
    lib.hideContext()
    QBCore.Functions.Notify('Menú cerrado', 'primary')
end)

-- SPAWN & TARGET
CreateThread(function()
    local m = `prop_parkingpay`
    RequestModel(m)
    while not HasModelLoaded(m) do Wait(100) end
    local obj = CreateObject(m, targetUbicacion.x, targetUbicacion.y, targetUbicacion.z - 1, true, true, true)
    FreezeEntityPosition(obj, true)
    SetEntityInvincible(obj, true)
    exports['qb-target']:AddTargetEntity(obj, {
        options = {{
            icon = 'fas fa-paint-roller',
            label = 'Abrir modificaciones',
            action = function()
                local ped = PlayerPedId()
                local veh = GetVehiclePedIsIn(ped, false)
                if veh == 0 then
                    QBCore.Functions.Notify('Dentro de un vehículo', 'error')
                    return
                end
                currentVeh = VehToNet(veh)
                OpenMainLiveryMenu()
            end,
            keepOpen = true
        }},
        distance = distanciaMax
    })
end)
