-- CLIENT SIDE - GARAGE POLICIAL CON NUI + qb-target

local QBCore  = exports['qb-core']:GetCoreObject()
local menuOpen = false

-- ► Configuración embebida (no hace falta config.lua)
local Config = {
    GarageLocation = vector3(441.54, -974.68, 25.7),
    SpawnLocation  = vector4(458.47, -993.34, 25.21, 358.16),
    Divisions = {
        LSPD = {
            label = "LSPD",
            vehicles = {
            { model = 'pbus',         name = 'Police Prison Bus',        brand = 'Vapid',   rank = 2 },
            { model = 'policet',      name = 'Police Transporter',       brand = 'Vapid',   rank = 1 },
            { model = 'policeb',      name = 'Police Bike',              brand = 'Vapid',   rank = 0 },
            { model = 'nkstx',        name = 'Buffalo STX Pol',          brand = 'Bravado', rank = 1 },
            { model = 'polcoach',     name = 'Academia Bus',             brand = 'Vapid',   rank = 2 },
            { model = 'nkstanier',    name = 'Stanier Pol',              brand = 'Vapid',   rank = 2 },
            { model = 'polcaracara',  name = 'Caracara Pol',             brand = 'Vapid',   rank = 2 },   
            { model = 'polcomet',     name = 'Comet Pol',                brand = 'Pfister', rank = 2 },   
            { model = 'poldom',       name = 'Dominator Pol',            brand = 'Vapid',   rank = 2 },   
            { model = 'polvigero2',   name = 'Vigero Pol',               brand = 'Declasse',rank = 2 },   
            { model = 'polvstr',      name = 'Vestra Pol',               brand = 'Albany',  rank = 2 },   
            { model = 'nkcoquette',   name = 'Coquette Pol',             brand = 'Inverto', rank = 2 },   
            { model = 'nkballer7',    name = 'Baller Pol',               brand = 'Gallivan',rank = 2 },   
            { model = 'nkbison',      name = 'Bison Pol',                brand = 'Bravado', rank = 2 },   
            { model = 'nkbuffalos',   name = 'BuffaloS Pol',             brand = 'Bravado', rank = 2 },   
            { model = 'nkcoquette4',  name = 'SuperCoquette Pol',        brand = 'Inverto', rank = 2 },   
            { model = 'nkgauntlet4',  name = 'Gauntlet Pol',             brand = 'Bravado', rank = 2 },   
            { model = 'nkgranger2',   name = 'Granger Pol',              brand = 'Declasse',rank = 2 },   
            { model = 'nkscout',      name = 'Scout Pol',                brand = 'Vapid',   rank = 2 },   
            { model = 'nkscout2020',  name = 'Scout 2020 Pol',           brand = 'Vapid',   rank = 2 },   
            { model = 'polbuffev',    name = 'BuffaloEv Pol',            brand = 'Bravado', rank = 2 },   
            { model = 'polweevil',    name = 'Escarabajo Pol',           brand = 'BF',      rank = 2 },   
            { model = 'lspdwood',     name = 'Greenwood Pol',            brand = 'Greenwood',rank = 2 },   
            { model = 'polbuffwb',    name = 'Buffalo Wide Pol',         brand = 'Bravado', rank = 2 },
            { model = 'nkcruiser',    name = 'Cruiser Pol',              brand = 'Vapid',   rank = 2 },   
            { model = 'r1200rtp',     name = 'R1200 Pol',                brand = 'Dinka',   rank = 2 },   
            { model = 'pbike',        name = 'Bicicleta Pol',            brand = 'Bike',    rank = 2 },   
            { model = 'nkbf400',      name = 'BF400 Pol',                brand = 'Nagasaki', rank = 2 },   
            { model = 'segway',       name = 'Segway Pol',               brand = 'Segway',  rank = 2 },
                -- ...añade el resto de LSPD...
            }
        },
        METRO = {
            label = "METRO",
            vehicles = {
                { model = 'riot',  name = 'Police Riot',       brand = 'Brute',   rank = 4 },
                { model = 'riot2', name = 'RCV',               brand = 'Unknown', rank = 3 },
                { model = 'pbus',  name = 'Police Prison Bus', brand = 'Vapid',   rank = 2 },
            }
        },
        DB = {
            label = "DB",
            vehicles = {
                { model = 'riot',    name = 'DB Riot',        brand = 'Brute',   rank = 4 },
                { model = 'riot2',   name = 'DB RCV',         brand = 'Unknown', rank = 3 },
                { model = 'pbus',    name = 'DB Prison Bus',  brand = 'Vapid',   rank = 2 },
                { model = 'police2', name = 'DB Buffalo',     brand = 'Vapid',   rank = 0 },
                { model = 'police3', name = 'DB Interceptor', brand = 'Vapid',   rank = 1 },
            }
        },
        RTD = {
            label = "RTD",
            vehicles = {
                { model = 'police2', name = 'RTD Buffalo',     brand = 'Vapid', rank = 0 },
                { model = 'police3', name = 'RTD Interceptor', brand = 'Vapid', rank = 1 },
                { model = 'policeb', name = 'RTD Bike',        brand = 'Vapid', rank = 0 },
            }
        }
    }
}

-- ► Crear el ped y target
CreateThread(function()
    local model = `s_m_y_cop_01`
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(10) end

    local ped = CreatePed(4, model,
        Config.GarageLocation.x,
        Config.GarageLocation.y,
        Config.GarageLocation.z - 1.0,
        180.0, false, true)
        

    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    loadAnimDict("amb@world_human_cop_idles@male@idle_b")
    TaskPlayAnim(ped, "amb@world_human_cop_idles@male@idle_b", "idle_e",
        8.0, -8, -1, 1, 0, false, false, false)

    exports['qb-target']:AddTargetEntity(ped, {
        options = {
            {
                icon    = "fas fa-car",
                label   = "Abrir Garage Policial",
                action  = function()
                    if menuOpen then return end
                    menuOpen = true
                    SetNuiFocus(true, true)
                    SendNUIMessage({
                        action = 'openGarageMenu',
                        data   = Config.Divisions
                    })
                end,
                job     = "police",
            },
            {
                icon    = "fas fa-warehouse",
                label   = "Guardar Vehículo",
                action  = SaveToNearestGarage,
                job     = "police",
            }
        },
        distance = 3.0
    })
end)

-- ► NUI callbacks
RegisterNUICallback('closeMenu', function(_, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

RegisterNUICallback('spawnVehicle', function(data, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    QBCore.Functions.SpawnVehicle(data.model, function(veh)
        local plate = "POL" .. tostring(math.random(10000, 99999))
        SetVehicleNumberPlateText(veh, plate)
        SetEntityHeading(veh, Config.SpawnLocation.w)
        SetVehicleEngineOn(veh, true, true, true)
        SetVehicleFuelLevel(veh, 100.0)
        TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
        TriggerEvent("vehiclekeys:client:SetOwner", plate)
        QBCore.Functions.Notify("Vehículo asignado: " .. plate, "success")
    end, Config.SpawnLocation, true)
    cb({})
end)

RegisterNUICallback('menuStateChange', function(data, cb)
    menuOpen = data.menuOpen
    SetNuiFocus(data.menuOpen, data.menuOpen)
    cb({})
end)


-- ► Función de “guardar” (despawn)
function SaveToNearestGarage()
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh == 0 then
        return QBCore.Functions.Notify("No estás en un vehículo.", "error")
    end
    TaskLeaveVehicle(PlayerPedId(), veh, 0)
    Wait(500)
    QBCore.Functions.DeleteVehicle(veh)
    QBCore.Functions.Notify("Vehículo retirado del servicio.", "success")
end

-- ► Anim dict helper
function loadAnimDict(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(10) end
end
