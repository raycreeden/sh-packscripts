Config = {}

Config.GarageLocation = vector3(461.45, -980.0, 25.21)
Config.SpawnLocation = vector4(458.39, -992.54, 25.18, 3.65)

-- 🔹 Definición de divisiones con colores y vehículos
Config.Divisions = {
    LSPD = {
        label = "LSPD",
        vehicles = {
            { model = 'pbus',         name = 'Police Prison Bus',        brand = 'Vapid',   rank = 2 },
            { model = 'policet',      name = 'Police Transporter',       brand = 'Vapid',   rank = 1 },
            { model = 'policeb',      name = 'Police Bike',              brand = 'Vapid',   rank = 0 },
            { model = 'nkstx',        name = 'Buffalo STX Pol',          brand = 'Bravado', rank = 1 },
            { model = 'polcoach',     name = 'Academia Bus',             brand = 'Vapid',   rank = 2 },
            { model = 'nkstanier',    name = 'Stanier Pol',              brand = 'Vapid',   rank = 2 },
            { model = 'polcaracara',  name = 'Caracara Pol',             brand = 'Vapid',   rank = 2 },   
            { model = 'polcomet',     name = 'Comet Pol',                brand = 'Pfister', rank = 2 },   
            { model = 'poldom',       name = 'Dominator Pol',            brand = 'Vapid',   rank = 2 },   
            { model = 'polvigero2',   name = 'Vigero Pol',               brand = 'Declasse',rank = 2 },   
            { model = 'polvstr',      name = 'Vestra Pol',               brand = 'Albany',  rank = 2 },   
            { model = 'nkcoquette',   name = 'Coquette Pol',             brand = 'Inverto', rank = 2 },   
            { model = 'nkballer7',    name = 'Baller Pol',               brand = 'Gallivan',rank = 2 },   
            { model = 'nkbison',      name = 'Bison Pol',                brand = 'Bravado', rank = 2 },   
            { model = 'nkbuffalos',   name = 'BuffaloS Pol',             brand = 'Bravado', rank = 2 },   
            { model = 'nkcoquette4',  name = 'SuperCoquette Pol',        brand = 'Inverto', rank = 2 },   
            { model = 'nkgauntlet4',  name = 'Gauntlet Pol',             brand = 'Bravado', rank = 2 },   
            { model = 'nkgranger2',   name = 'Granger Pol',              brand = 'Declasse',rank = 2 },   
            { model = 'nkscout',      name = 'Scout Pol',                brand = 'Vapid',   rank = 2 },   
            { model = 'nkscout2020',  name = 'Scout 2020 Pol',           brand = 'Vapid',   rank = 2 },   
            { model = 'polbuffev',    name = 'BuffaloEv Pol',            brand = 'Bravado', rank = 2 },   
            { model = 'polweevil',    name = 'Escarabajo Pol',           brand = 'BF',      rank = 2 },   
            { model = 'lspdwood',     name = 'Greenwood Pol',            brand = 'Greenwood',rank = 2 },   
            { model = 'polbuffwb',    name = 'Buffalo Wide Pol',         brand = 'Bravado', rank = 2 },
            { model = 'nkcruiser',    name = 'Cruiser Pol',              brand = 'Vapid',   rank = 2 },   
            { model = 'r1200rtp',     name = 'R1200 Pol',                brand = 'Dinka',   rank = 2 },   
            { model = 'pbike',        name = 'Bicicleta Pol',            brand = 'Bike',    rank = 2 },   
            { model = 'nkbf400',      name = 'BF400 Pol',                brand = 'Nagasaki', rank = 2 },   
            { model = 'segway',       name = 'Segway Pol',               brand = 'Segway',  rank = 2 },
        }
    },
    METRO = {
        label = "METRO",
        vehicles = {
            { model = 'riot',         name = 'Police Riot',              brand = 'Brute',   rank = 4 },
            { model = 'riot2',        name = 'RCV',                      brand = 'Unknown', rank = 3 },
            { model = 'pbus',         name = 'Police Prison Bus',        brand = 'Vapid',   rank = 2 },
        }
    },
    DB = {
        label = "DB",
        vehicles = {
            { model = 'riot',         name = 'DB Riot',              brand = 'Brute',   rank = 4 },
            { model = 'riot2',        name = 'DB RCV',               brand = 'Unknown', rank = 3 },
            { model = 'pbus',         name = 'DB Prison Bus',        brand = 'Vapid',   rank = 2 },
            { model = 'police2',      name = 'DB Buffalo',           brand = 'Vapid',   rank = 0 },
            { model = 'police3',      name = 'DB Interceptor',       brand = 'Vapid',   rank = 1 },
        }
    },
    RTD = {
        label = "RTD",
        vehicles = {
            { model = 'police2',      name = 'RTD Buffalo',          brand = 'Vapid',   rank = 0 },
            { model = 'police3',      name = 'RTD Interceptor',      brand = 'Vapid',   rank = 1 },
            { model = 'policeb',      name = 'RTD Bike',             brand = 'Vapid',   rank = 0 },
        }
    }
}
