fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'SherlockCo'
description 'Turbo temporal individual'
version '1.0.2'

client_script 'client.lua'
