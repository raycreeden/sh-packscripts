local QBCore = exports['qb-core']:GetCoreObject()
local turboCoords = vector3(436.31, -976.18, 25.7)
local maxDistance = 3.0
local boostedVehicles = {}

-- Lista de vehículos habilitados para turbo
local allowedModels = {
    ["polgauntlet"] = true,
    ["polbuffev"] = true,
    ["polweevil"] = true,
    ["nkstx"] = true,
    ["policeb"] = true,
    ["polbuffwb"] = true,

    -- Agregá más así: ["nombre_modelo"] = true
}

RegisterCommand("turbo", function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local dist = #(coords - turboCoords)

    if dist > maxDistance then
        QBCore.Functions.Notify("No estás en la zona de activación del turbo.", "error")
        return
    end

    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then
        QBCore.Functions.Notify("Debes estar dentro del vehículo para activarle el turbo.", "error")
        return
    end

    local model = GetEntityModel(veh)
    local modelName = GetDisplayNameFromVehicleModel(model):lower()

    if not allowedModels[modelName] then
        QBCore.Functions.Notify("Este vehículo no tiene acceso al turbo especial.", "error")
        return
    end

    local plate = GetVehicleNumberPlateText(veh)
    if boostedVehicles[plate] then
        QBCore.Functions.Notify("Este vehículo ya tiene turbo activado.", "primary")
        return
    end

    boostedVehicles[plate] = true

    -- Aplicamos turbo al handling
    local currentForce = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveForce')
    local newForce = currentForce * 1.75

    ModifyVehicleTopSpeed(veh, 20.0)
    SetVehicleHandlingFloat(veh, 'CHandlingData', 'fInitialDriveForce', newForce)

    QBCore.Functions.Notify("🚀 Turbo activado en " .. modelName .. ". Que ni el GPS te siga.", "success", 4000)
end)
