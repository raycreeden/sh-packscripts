local QBCore = exports['qb-core']:GetCoreObject()

RegisterCommand("listarmods", function()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then
        QBCore.Functions.Notify("No estás dentro de un vehículo", "error")
        return
    end

    print("----- Mods y Extras del Vehículo -----")

    for modType = 0, 49 do
        local count = GetNumVehicleMods(veh, modType)
        if count > 0 then
            print(string.format("ModType %d, opciones %d", modType, count))
            for i = 0, count - 1 do
                local label = GetModTextLabel(veh, modType, i)
                local name = label and GetLabelText(label) or "Sin nombre"
                print(string.format("  modIndex %d = %s", i, name))
            end
        end
    end

    for extraId = 0, 20 do
        if DoesExtraExist(veh, extraId) then
            print(string.format("Extra %d existe", extraId))
        end
    end

    local liveryCount = GetVehicleLiveryCount(veh)
    print("Liveries disponibles: " .. liveryCount)
    for i = 0, liveryCount - 1 do
        print("  Livery " .. i)
    end
end)
