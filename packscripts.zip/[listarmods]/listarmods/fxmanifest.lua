fx_version 'cerulean'
game 'gta5'

client_scripts {
    'listarmods.lua'
}
